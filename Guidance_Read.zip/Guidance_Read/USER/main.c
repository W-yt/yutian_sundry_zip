/**
  ******************************************************************************
  * @file    main
  * @author  Wu
  * @version V0.0
  * @date    15-January-2019
  * @brief   
  ******************************************************************************
  */

/* Includes */
#include "config.h"
#include "uart.h"

/* data define */


int main( void )
{
	delay_init();
	Usart2_Init();
	
	while( 1 )
	{
		;
	}
}






