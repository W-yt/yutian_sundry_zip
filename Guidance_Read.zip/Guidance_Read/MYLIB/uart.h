/* Define to prevent recursive inclusion */
#ifndef __STM32F4_UART_H
#define __STM32F4_UART_H

/* Includes */
#include "stm32f4xx.h"

/* Exported types ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/
void Usart2_Init(void);

#endif


