/* Includes */
#include "config.h"
#include "uart.h"

/* data define */


int main( void )
{
	delay_init();
	Usart2_Init();
	Uart4_Init();
	
	while( 1 )
	{
		;
	}
}






