#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder1_Init(void);
void Encoder2_Init(void);
void Encoder_init(void);

void Encoder1_read(void);
void Encoder2_read(void);

#endif

