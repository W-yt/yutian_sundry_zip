#ifndef __USART_H
#define __USART_H


void usart_init(void);
void USART1_Dataset(void);
u8 RC_Data_Solve(void);


#endif

