#ifndef __ADC_H
#define __ADC_H

#include "stm32f10x.h"


void ADC_Configuration(void);
void ADC_read(void);
void Get_Adc_Check(void); 


#endif


