#ifndef __DELAY_H__
#define __DELAY_H__

#include "main.h"

void delay_init(void);
void delay_us(u32 ntime);
void delay_ms(u32 ntime);

#endif
