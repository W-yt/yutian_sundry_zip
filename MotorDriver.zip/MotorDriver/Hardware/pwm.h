#ifndef __PWM_H
#define __PWM_H

#include "main.h"

void TIM4_PWM_Init(void);
void TIM4_PWM_OUTPUT(u16 DR1,u16 DR2,u16 DR3,u16 DR4);


#endif
