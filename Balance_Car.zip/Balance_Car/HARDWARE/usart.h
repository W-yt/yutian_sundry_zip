#ifndef __USART_H
#define __USART_H

#include "stdio.h"	
#include "stm32f10x.h" 

void usart1_init(void);
void usart2_init(void);
u8 RC_Data_Solve(void);

#endif

