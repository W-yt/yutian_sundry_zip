#ifndef __ENCODER_H
#define __ENCODER_H


#include "main.h"


void encoder1_init(void);
void encoder2_init(void);
void encoder_init(void);
int encoder_read(u8 EncoderX);


#endif




