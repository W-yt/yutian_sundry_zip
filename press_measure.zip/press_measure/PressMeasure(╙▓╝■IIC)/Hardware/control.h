#ifndef __CONTROL_H
#define __CONTROL_H

void Tim1_configration(void);
void GetData_Encoder(void);
void test_mode(void);


#endif


