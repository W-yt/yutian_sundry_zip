#ifndef __USART_H
#define __USART_H


void usart_init(void);

#endif

