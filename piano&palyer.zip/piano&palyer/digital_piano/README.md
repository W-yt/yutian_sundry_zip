+ 这是华中科技大学电信系2010级本科生硬件课程设计项目
+ 本项目开发语言为verilog硬件描述语言，采用Xilinx公司的集成开发环境ISE
+ 所采用的开发板是Diginlent公司Basys2板
+ 该项目实现功能：
   1. 电子琴3个音阶，共24个音符的输出
   2. 标准PS2键盘输入弹奏
   3. 标准VGA接口音符输出
   4. 时长8秒的录音回放功能
   5. 自制模拟放大电路
+ 如果想了解跟多，请移步: http://blog.csdn.net/ricky_hust/article/details/9766385 这是我在CSDN技术博客上贴出自己的总结报告
+ 项目作者：Cheng Zhang , Ziping Zhao , Jiao Li
