#ifndef __SOLVE_H
#define __SOLVE_H 	

#include "stm32f10x.h"  

void Place_Data_Slove(u8 *PC_DATA);

#endif
