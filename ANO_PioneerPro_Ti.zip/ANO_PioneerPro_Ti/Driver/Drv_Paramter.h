#ifndef _DRV_PARAMTER_H_
#define _DRV_PARAMTER_H_

#include "sysconfig.h"

void Dvr_ParamterInit(void);
void Dvr_ParamterRead(void);
void Dvr_ParamterSave(void);

#endif

