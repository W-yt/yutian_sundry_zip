#ifndef __WP_ADC_H__
#define __WP_ADC_H__


void ADC_Init(void);   
void Get_Battery_Voltage(void);  

extern float Battery_Voltage;

#endif
