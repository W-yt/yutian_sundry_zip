#ifndef __WP_PWM_H__
#define __WP_PWM_H__




void Init_PWM(void);
void PWM_Output(uint16_t width1,uint16_t width2,uint16_t width3,uint16_t width4,
	              uint16_t width5,uint16_t width6,uint16_t width7,uint16_t width8);


#endif


