#ifndef __ppm_h__
#define __ppm_h__

void PPM_Init(void);
extern uint16 PPM_Databuf[8];
extern uint8_t PPM_Safety_Flag;
#endif
