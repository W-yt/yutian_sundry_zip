#ifndef __USART_H__
#define __USART_H__

void vUart3Config(void);
void vUart1Config(void);

#endif

/* end */










